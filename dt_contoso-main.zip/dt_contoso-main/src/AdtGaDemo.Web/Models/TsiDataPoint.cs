using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdtGaDemo.Web.Models
{
  public class TsiDataPoint
  {
    public double Avg { get; set; }
  }
}
