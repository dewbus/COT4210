#!/bin/bash
cd src/AdtGaDemo.Web/ClientApp
npx serve build -s