##########################################################################################################
--This doc provides instructions on how to run ADT-Supply-Chain-Demo Locally from pulling intially from github---


1. Make an Anaconda Environment with Python 2.7 installed

2. Navigate to the Python Excutable for Virtual Environment and change name from "python" to "python2"
    - C:\Users\<username>\AppData\Local\anaconda3\envs\<env_name>\python.exe to C:\Users\<username>\AppData\Local\anaconda3\envs\<env_name>\python2.exe
    -Verify: python2 --version

3. Navigate to Client App
 - Could look like: cd C:\Users\<user_name>\IoTDemos\ADT-SupplyChainDemo\src\AdtGaDemo.Web\ClientApp

4. Replace deprecated node-sass library with sass
    - npm uninstall node-sass
    - npm install sass --save-dev
    
6. Set Node_Options variable to legacy
    - set NODE_OPTIONS=--openssl-legacy-provider

5. Run the build of the project
    - npm run build

6. Install serve for local running and run using npx:
    - npm install serve
    - npx serve -s build

7. Go to localhost:3000

###########################################################################################################


